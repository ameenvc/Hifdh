Hifdh grammar corresponding source
Original Quranic Arabic Corpus v0.4 data, pinned provenance and notices included.
From this archive root, run python3 scripts/build-grammar.py to regenerate grammar JSON.
Requires Python 3, no external dependencies. Create public/data/grammar if needed.
Quran text is provided as unchanged generator input under its own Tanzil terms.
The QAC data and derived grammar follow the included GPL terms.
Full application source: https://github.com/ameenvc/Hifdh
